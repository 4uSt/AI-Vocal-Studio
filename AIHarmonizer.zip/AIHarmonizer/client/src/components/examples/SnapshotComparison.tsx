import { SnapshotComparison } from '../SnapshotComparison';

export default function SnapshotComparisonExample() {
  return <SnapshotComparison />;
}
