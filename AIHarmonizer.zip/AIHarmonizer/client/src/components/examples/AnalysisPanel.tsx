import { AnalysisPanel } from '../AnalysisPanel';

export default function AnalysisPanelExample() {
  return <AnalysisPanel />;
}
