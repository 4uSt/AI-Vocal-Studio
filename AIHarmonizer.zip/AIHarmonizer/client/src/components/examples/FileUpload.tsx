import { FileUpload } from '../FileUpload';

export default function FileUploadExample() {
  return (
    <div className="max-w-md">
      <FileUpload />
    </div>
  );
}
