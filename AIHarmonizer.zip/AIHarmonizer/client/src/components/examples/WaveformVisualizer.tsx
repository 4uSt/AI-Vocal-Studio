import { WaveformVisualizer } from '../WaveformVisualizer';

export default function WaveformVisualizerExample() {
  return <WaveformVisualizer />;
}
