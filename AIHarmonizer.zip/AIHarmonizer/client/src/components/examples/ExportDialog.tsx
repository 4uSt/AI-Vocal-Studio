import { ExportDialog } from '../ExportDialog';

export default function ExportDialogExample() {
  return (
    <div className="p-4">
      <ExportDialog />
    </div>
  );
}
