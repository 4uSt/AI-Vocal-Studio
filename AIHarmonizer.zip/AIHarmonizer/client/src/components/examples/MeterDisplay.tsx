import { MeterDisplay } from '../MeterDisplay';

export default function MeterDisplayExample() {
  return <MeterDisplay />;
}
